import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Crosshair,
  Radio,
  RefreshCw,
  Satellite,
  Search,
  Ship,
} from 'lucide-react';
import { AisConnectionStatus } from '../services/aisStreamService';
import {
  CableProximityAlert,
  DarkEnvelopeState,
  HudMode,
  Incident,
  IncidentFilter,
  SatelliteGroundState,
  Vessel,
} from '../types/telemetry';

interface IncidentTriagePanelProps {
  hudMode: HudMode;
  incidents: Incident[];
  liveVessels: Vessel[];
  darkEnvelopes?: DarkEnvelopeState[];
  cableThreatAlerts?: CableProximityAlert[];
  nextSatellitePass?: SatelliteGroundState;
  aisStatus: AisConnectionStatus;
  aisError?: string;
  activeFilter: IncidentFilter;
  selectedIncidentId: string;
  selectedVesselId: string | null;
  onChangeFilter: (filter: IncidentFilter) => void;
  onLocateIncident: (incident: Incident) => void;
  onInspectIncident: (incident: Incident) => void;
  onSelectLiveVessel: (vessel: Vessel, flyTo: boolean) => void;
  onReconnectAis: () => void;
}

function formatShortCountdown(totalSeconds: number): string {
  const clamped = Math.max(0, Math.floor(totalSeconds));
  const hrs = Math.floor(clamped / 3600);
  const mins = Math.floor((clamped % 3600) / 60);
  const secs = clamped % 60;
  return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

const FILTER_OPTIONS: Array<{ id: IncidentFilter; label: string }> = [
  { id: 'all', label: 'ALL' },
  { id: 'dark_spoofing', label: 'DARK & SPOOFING' },
  { id: 'oil_spills', label: 'OIL SPILLS' },
  { id: 'subsea_cables', label: 'SUBSEA CABLES' },
];

export const IncidentTriagePanel: React.FC<IncidentTriagePanelProps> = ({
  hudMode,
  incidents,
  liveVessels,
  darkEnvelopes = [],
  cableThreatAlerts = [],
  nextSatellitePass,
  aisStatus,
  aisError,
  activeFilter,
  selectedIncidentId,
  selectedVesselId,
  onChangeFilter,
  onLocateIncident,
  onInspectIncident,
  onSelectLiveVessel,
  onReconnectAis,
}) => {
  const [panelView, setPanelView] = useState<'live_ais' | 'forensic'>(
    hudMode === 'surveillance' ? 'live_ais' : 'forensic'
  );
  const [vesselQuery, setVesselQuery] = useState('');

  useEffect(() => {
    setPanelView(hudMode === 'surveillance' ? 'live_ais' : 'forensic');
  }, [hudMode]);

  const darkMap = new Map<string, DarkEnvelopeState>();
  darkEnvelopes.forEach((d) => darkMap.set(d.vesselId, d));

  const cableAlertMap = new Map<string, CableProximityAlert>();
  cableThreatAlerts.forEach((a) => cableAlertMap.set(a.vesselId, a));

  const confirmedDarkEnvelopes = darkEnvelopes.filter((d) => d.isConfirmedDark);
  const routineGapCount = darkEnvelopes.length - confirmedDarkEnvelopes.length;

  const filteredLiveVessels = liveVessels
    .filter((v) => {
      const q = vesselQuery.trim().toLowerCase();
      if (!q) return true;
      return (
        v.name.toLowerCase().includes(q) ||
        v.mmsi.toLowerCase().includes(q) ||
        v.vesselType.toLowerCase().includes(q) ||
        (v.destination ?? '').toLowerCase().includes(q)
      );
    })
    .sort((a, b) => {
      const scoreA = (darkMap.get(a.id)?.isConfirmedDark ? 2 : 0) + (cableAlertMap.has(a.id) ? 1 : 0);
      const scoreB = (darkMap.get(b.id)?.isConfirmedDark ? 2 : 0) + (cableAlertMap.has(b.id) ? 1 : 0);
      return scoreB - scoreA;
    });

  const firstDarkVessel = confirmedDarkEnvelopes[0]
    ? liveVessels.find((v) => v.id === confirmedDarkEnvelopes[0].vesselId)
    : undefined;
  const firstCableAlertVessel = cableThreatAlerts[0]
    ? liveVessels.find((v) => v.id === cableThreatAlerts[0].vesselId)
    : undefined;

  return (
    <aside
      aria-label="Live AIS Targets and Threat Triage"
      className="fixed top-[4.5rem] left-3 bottom-[6.75rem] z-[900] w-80 hud-glass rounded-md flex flex-col overflow-hidden"
    >
      {/* Header */}
      <div className="px-3.5 py-2.5 border-b border-cyan-500/20 flex items-center justify-between">
        <div>
          <h2 className="text-xs font-semibold tracking-wider text-slate-100 uppercase">
            {panelView === 'live_ais' ? 'Live AIS Maritime Feed' : 'Threat & Pollution Triage'}
          </h2>
          <p className="text-[11px] font-mono text-slate-400 mt-0.5">
            {panelView === 'live_ais'
              ? `${liveVessels.length} real AIS vessels · Med-East`
              : `${incidents.length} prioritized ${incidents.length === 1 ? 'case' : 'cases'} · Sorted by risk`}
          </p>
        </div>
        <span className="text-[11px] font-mono text-cyan-300">MED-EAST</span>
      </div>

      {/* AUTONOMOUS WATCHDOG FEED Card (Live Real-Time Alerts) */}
      <div className="px-3 py-2 border-b border-cyan-500/20 bg-[#040916]/90 space-y-1.5">
        <div className="flex items-center justify-between text-[9.5px] font-mono">
          <span className="text-cyan-300 font-bold tracking-wider flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>AUTONOMOUS WATCHDOG FEED</span>
          </span>
          <span className="text-slate-400">30m DARK · 3km CABLE</span>
        </div>

        <div className="grid grid-cols-3 gap-1.5 font-mono">
          <button
            type="button"
            disabled={!firstDarkVessel}
            onClick={() => firstDarkVessel && onSelectLiveVessel(firstDarkVessel, true)}
            className={`text-left rounded p-1.5 border transition-colors ${
              confirmedDarkEnvelopes.length > 0
                ? 'bg-rose-950/45 border-rose-500/60 hover:border-rose-400 cursor-pointer'
                : 'bg-[#050c1a]/80 border-slate-800/80 cursor-default'
            }`}
          >
            <div className="text-[8.5px] text-slate-400">DARK (&gt;30M)</div>
            <div
              className={`text-xs font-bold mt-0.5 ${
                confirmedDarkEnvelopes.length > 0 ? 'text-rose-300' : 'text-emerald-400'
              }`}
            >
              {confirmedDarkEnvelopes.length} DARK
            </div>
            {routineGapCount > 0 && confirmedDarkEnvelopes.length === 0 && (
              <div className="text-[8px] text-emerald-300/85 truncate">
                {routineGapCount} brief &lt;30m
              </div>
            )}
          </button>

          <button
            type="button"
            disabled={!firstCableAlertVessel}
            onClick={() => firstCableAlertVessel && onSelectLiveVessel(firstCableAlertVessel, true)}
            className={`text-left rounded p-1.5 border transition-colors ${
              cableThreatAlerts.length > 0
                ? 'bg-amber-950/40 border-rose-500/55 hover:border-rose-400 cursor-pointer'
                : 'bg-[#050c1a]/80 border-slate-800/80 cursor-default'
            }`}
          >
            <div className="text-[8.5px] text-slate-400">CABLE ALERTS</div>
            <div
              className={`text-xs font-bold mt-0.5 ${
                cableThreatAlerts.length > 0 ? 'text-amber-300' : 'text-emerald-400'
              }`}
            >
              {cableThreatAlerts.length} THREATS
            </div>
          </button>

          <div className="rounded p-1.5 border bg-[#050c1a]/80 border-cyan-500/30">
            <div className="text-[8.5px] text-slate-400 flex items-center gap-1 truncate">
              <Satellite className="w-2.5 h-2.5 text-cyan-400 shrink-0" />
              <span className="truncate">{nextSatellitePass?.name ?? 'SAR PASS'}</span>
            </div>
            <div className="text-[11px] font-bold text-cyan-300 mt-0.5 tabular-nums">
              {nextSatellitePass ? `T-${formatShortCountdown(nextSatellitePass.nextPassSeconds)}` : '--:--:--'}
            </div>
          </div>
        </div>
      </div>

      {/* View Switcher: Live AIS vs Forensic Cases */}
      <div className="px-3 py-2 border-b border-cyan-500/15 grid grid-cols-2 gap-1.5 bg-[#040812]/60">
        <button
          type="button"
          onClick={() => setPanelView('live_ais')}
          className={`px-2 py-1.5 text-[10px] font-mono font-semibold rounded-xs border flex items-center justify-center gap-1 transition-colors whitespace-nowrap ${
            panelView === 'live_ais'
              ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-200'
              : 'bg-slate-900/60 border-slate-700/50 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Radio className="w-3 h-3" />
          <span>LIVE AIS ({liveVessels.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setPanelView('forensic')}
          className={`px-2 py-1.5 text-[10px] font-mono font-semibold rounded-xs border flex items-center justify-center gap-1 transition-colors whitespace-nowrap ${
            panelView === 'forensic'
              ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-200'
              : 'bg-slate-900/60 border-slate-700/50 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Search className="w-3 h-3" />
          <span>FORENSIC ({incidents.length})</span>
        </button>
      </div>

      {panelView === 'live_ais' ? (
        <>
          {/* Search filter for live AIS targets */}
          <div className="px-3 py-2 border-b border-cyan-500/15 bg-[#040812]/40">
            <input
              type="text"
              value={vesselQuery}
              onChange={(e) => setVesselQuery(e.target.value)}
              placeholder="Filter name, MMSI, type, destination..."
              className="w-full px-2.5 py-1.5 text-[11px] font-mono rounded bg-[#040812] border border-slate-700/80 focus:border-cyan-400 focus:outline-none text-slate-100 placeholder:text-slate-500"
            />
          </div>

          <div className="flex-1 overflow-y-auto hud-scroll p-3 space-y-2">
            {filteredLiveVessels.length === 0 ? (
              <div className="bg-[#050c1a]/85 border border-cyan-500/25 rounded-md p-3.5 space-y-2.5 text-center">
                <div className="w-8 h-8 rounded-full bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center mx-auto text-cyan-300">
                  <Ship className="w-4 h-4" />
                </div>
                {aisStatus === 'connected' ? (
                  <>
                    <h3 className="text-xs font-mono font-semibold text-emerald-300 uppercase">
                      AISStream Connected
                    </h3>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      Listening to real-time VHF AIS frames across Alexandria, Damietta, Port Said,
                      and Northern Suez Approach. Ships appear immediately as transponders report.
                    </p>
                  </>
                ) : aisStatus === 'connecting' ? (
                  <>
                    <h3 className="text-xs font-mono font-semibold text-cyan-300 uppercase">
                      Connecting to AISStream...
                    </h3>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      Opening server-side WebSocket stream for Egyptian Eastern Mediterranean AIS
                      targets.
                    </p>
                  </>
                ) : (
                  <>
                    <h3 className="text-xs font-mono font-semibold text-amber-300 uppercase">
                      {aisStatus === 'error' ? 'AISStream Connection Error' : 'AISStream Relay Offline'}
                    </h3>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      {aisError
                        ? aisError
                        : 'Server AIS WebSocket stream is currently offline. Reconnect to resume live Eastern Mediterranean transponder telemetry.'}
                    </p>
                    <button
                      type="button"
                      onClick={onReconnectAis}
                      className="w-full py-2 px-3 rounded bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/50 text-[11px] font-mono font-semibold text-cyan-100 flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>RECONNECT AIS STREAM</span>
                    </button>
                  </>
                )}
              </div>
            ) : (
              filteredLiveVessels.map((v) => {
                const isSelected = selectedVesselId === v.id;
                const darkEnv = darkMap.get(v.id);
                const isConfirmedDark = Boolean(darkEnv?.isConfirmedDark);
                const isRoutineGap = Boolean(darkEnv && !darkEnv.isConfirmedDark && darkEnv.gapMinutes >= 0.5);
                const cableAlert = cableAlertMap.get(v.id);
                const isThreat = Boolean(isConfirmedDark || cableAlert);
                return (
                  <article
                    key={v.id}
                    onClick={() => onSelectLiveVessel(v, true)}
                    className={`rounded-md p-2.5 border transition-colors cursor-pointer ${
                      isThreat
                        ? isSelected
                          ? 'bg-rose-950/45 border-rose-400/75 shadow-[inset_0_0_18px_rgba(255,42,95,0.16)]'
                          : 'bg-rose-950/25 border-rose-500/45 hover:border-rose-400/70'
                        : isSelected
                          ? 'bg-emerald-950/35 border-emerald-400/60 shadow-[inset_0_0_18px_rgba(52,211,153,0.1)]'
                          : 'bg-[#070f20]/70 border-slate-700/60 hover:border-emerald-400/40'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 text-[10px] font-mono text-slate-400">
                      <span
                        className={`font-semibold ${
                          isThreat ? 'text-rose-300' : 'text-emerald-300'
                        }`}
                      >
                        MMSI {v.mmsi}
                      </span>
                      {isConfirmedDark && darkEnv ? (
                        <span className="px-1.5 py-0.5 rounded-xs bg-rose-500/25 border border-rose-400/60 text-rose-200 text-[9px] font-bold">
                          DARK ANOMALY · {Math.round(darkEnv.gapMinutes)}m (&gt;30m)
                        </span>
                      ) : cableAlert ? (
                        <span className="px-1.5 py-0.5 rounded-xs bg-amber-500/20 border border-rose-400/60 text-amber-200 text-[9px] font-bold flex items-center gap-1">
                          <AlertTriangle className="w-2.5 h-2.5 text-rose-400" />
                          <span>SUBSEA CABLE THREAT</span>
                        </span>
                      ) : isRoutineGap && darkEnv ? (
                        <span className="px-1.5 py-0.5 rounded-xs bg-emerald-500/15 border border-emerald-400/45 text-emerald-300 text-[9px] font-semibold">
                          ROUTINE GAP · {Math.round(darkEnv.gapMinutes)}m (&lt;30m)
                        </span>
                      ) : (
                        <span>
                          {v.flag} · {v.aisLastSeenUtc.slice(11, 19)}Z
                        </span>
                      )}
                    </div>
                    <h3 className="text-[12.5px] font-semibold text-slate-100 mt-1 truncate">
                      {v.name}
                    </h3>
                    <div className="text-[10.5px] font-mono text-slate-300 mt-0.5 truncate">
                      {v.vesselType}
                      {v.destination ? ` · → ${v.destination}` : ''}
                    </div>
                    {cableAlert && (
                      <div className="mt-1.5 text-[9.5px] font-mono text-amber-300 truncate">
                        ⚠ SUBSEA CABLE THREAT · {cableAlert.cableName} ({cableAlert.distanceKm} km)
                      </div>
                    )}
                    <div className="flex items-center justify-between gap-2 pt-2 mt-2 border-t border-slate-700/50 text-[10px] font-mono">
                      <span className="text-cyan-300">
                        {v.sogKts.toFixed(1)} kts · {v.headingDeg}°
                      </span>
                      <span className="text-slate-400">
                        {v.lat.toFixed(2)}°N, {v.lon.toFixed(2)}°E
                      </span>
                    </div>
                  </article>
                );
              })
            )}
          </div>
        </>
      ) : (
        <>
          {/* Interactive Filter Controls for Forensic Incidents */}
          <div className="px-3 py-2.5 border-b border-cyan-500/15 grid grid-cols-2 gap-1.5 bg-[#040812]/50">
            {FILTER_OPTIONS.map((opt) => {
              const isActive = activeFilter === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeFilter(opt.id)}
                  className={`px-2 py-1.5 text-[10px] font-mono font-medium rounded-xs border text-center transition-colors whitespace-nowrap truncate ${
                    isActive
                      ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-200'
                      : 'bg-slate-900/60 border-slate-700/50 text-slate-400 hover:text-slate-200 hover:border-slate-600'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>

          {/* Forensic Incident List */}
          <div className="flex-1 overflow-y-auto hud-scroll p-3 space-y-2.5">
            {incidents.length === 0 ? (
              <div className="py-10 text-center text-xs text-slate-400 font-mono">
                No active anomalies in selected filter.
              </div>
            ) : (
              incidents.map((inc) => {
                const isSelected = inc.id === selectedIncidentId;
                const severityText =
                  inc.severity === 'critical'
                    ? 'CRITICAL'
                    : inc.severity === 'high'
                      ? 'HIGH'
                      : 'MEDIUM';
                const severityColor =
                  inc.severity === 'critical'
                    ? 'text-rose-400'
                    : inc.severity === 'high'
                      ? 'text-amber-300'
                      : 'text-cyan-300';
                const scoreBorder =
                  inc.severity === 'critical'
                    ? 'border-rose-500/40 text-rose-300 bg-rose-500/10'
                    : inc.severity === 'high'
                      ? 'border-amber-500/40 text-amber-300 bg-amber-500/10'
                      : 'border-cyan-500/40 text-cyan-300 bg-cyan-500/10';

                return (
                  <article
                    key={inc.id}
                    onClick={() => onInspectIncident(inc)}
                    className={`rounded-md p-3 border transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-950/35 border-cyan-400/60 shadow-[inset_0_0_20px_rgba(0,240,255,0.08)]'
                        : 'bg-[#070f20]/70 border-slate-700/60 hover:border-cyan-500/35'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400 min-w-0 truncate">
                        <span className="text-slate-200 font-semibold">{inc.caseCode}</span>
                        <span aria-hidden="true">·</span>
                        <span className={`font-semibold ${severityColor}`}>{severityText}</span>
                        <span aria-hidden="true">·</span>
                        <span>{inc.timestampUtc.slice(11, 16)}Z</span>
                      </div>

                      <div
                        className={`px-1.5 py-0.5 rounded-xs border text-[11px] font-mono font-bold shrink-0 ${scoreBorder}`}
                        title="Threat Score (0-100)"
                      >
                        {inc.threatScore}
                      </div>
                    </div>

                    <h3 className="text-[12.5px] font-semibold text-slate-100 leading-snug mb-1.5">
                      {inc.shortTitle}
                    </h3>

                    <p className="text-[11px] text-slate-300/90 leading-relaxed line-clamp-3 mb-2.5">
                      {inc.summary}
                    </p>

                    <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-700/50">
                      <span className="text-[10px] font-mono text-slate-400">
                        {inc.lat.toFixed(2)}°N, {inc.lon.toFixed(2)}°E
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onLocateIncident(inc);
                          }}
                          className="px-2 py-1 text-[10px] font-mono font-medium rounded-xs border border-slate-600/70 text-slate-200 hover:border-cyan-400/60 hover:text-cyan-200 hover:bg-cyan-500/10 flex items-center gap-1 transition-colors whitespace-nowrap"
                        >
                          <Crosshair className="w-3 h-3" />
                          <span>LOCATE</span>
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onInspectIncident(inc);
                          }}
                          className={`px-2 py-1 text-[10px] font-mono font-medium rounded-xs border flex items-center gap-1 transition-colors whitespace-nowrap ${
                            isSelected
                              ? 'bg-cyan-500/25 border-cyan-400/70 text-cyan-100'
                              : 'bg-slate-800/70 border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/20'
                          }`}
                        >
                          <Search className="w-3 h-3" />
                          <span>INSPECT</span>
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })
            )}
          </div>
        </>
      )}
    </aside>
  );
};
