import React from 'react';
import { Download, Printer, X } from 'lucide-react';
import {
  HudMode,
  Incident,
  LiveForensicSnapshot,
  QueuedSarTask,
  Vessel,
  WeatherState,
} from '../types/telemetry';

interface ViolationDossierModalProps {
  hudMode: HudMode;
  incident: Incident;
  vessel: Vessel;
  weather: WeatherState;
  liveSnapshot: LiveForensicSnapshot;
  queuedSarTasks: QueuedSarTask[];
  onClose: () => void;
}

export const ViolationDossierModal: React.FC<ViolationDossierModalProps> = ({
  hudMode,
  incident,
  vessel,
  weather,
  liveSnapshot,
  queuedSarTasks,
  onClose,
}) => {
  const sar = incident.sarMetrics;
  const drift = incident.driftAttribution;
  const isSurveillance = hudMode === 'surveillance';

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadJson = () => {
    const payload = isSurveillance
      ? {
          generatedAtUtc: new Date().toISOString(),
          platform: 'AEGIS-SAR // MED-EAST ORBITAL COMMAND',
          mode: 'COASTAL_SURVEILLANCE_LIVE',
          targetVessel: vessel,
          liveForensicSnapshot: liveSnapshot,
          queuedSarTasks,
          environmentalContext: weather,
        }
      : {
          generatedAtUtc: new Date().toISOString(),
          platform: 'AEGIS-SAR // MED-EAST ORBITAL COMMAND',
          mode: 'FORENSIC_CASE_LAB',
          incident,
          vessel,
          environmentalContext: weather,
        };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const safeSlug = isSurveillance
      ? liveSnapshot.targetLabel.toLowerCase().replace(/[^a-z0-9]+/g, '-')
      : incident.caseCode.toLowerCase();
    a.download = `${safeSlug}-${isSurveillance ? 'live-surveillance' : 'forensic'}-dossier.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isSurveillance) {
    const {
      dopplerPhysics,
      localMetocean,
      cableRisk,
      financialLiability,
      darkEnvelope,
      sgp4Intercept,
      oilSimulation,
    } = liveSnapshot;

    const matchingTasks = queuedSarTasks.filter(
      (t) => t.targetVesselId === vessel.id || t.mmsi === vessel.mmsi
    );
    const displayedTasks = matchingTasks.length > 0 ? matchingTasks : queuedSarTasks;

    const riskBadgeClass =
      financialLiability.riskTier === 'CRITICAL'
        ? 'border-rose-500/60 bg-rose-500/15 text-rose-300'
        : financialLiability.riskTier === 'HIGH'
          ? 'border-amber-500/60 bg-amber-500/15 text-amber-300'
          : financialLiability.riskTier === 'MODERATE'
            ? 'border-cyan-500/60 bg-cyan-500/15 text-cyan-300'
            : 'border-emerald-500/60 bg-emerald-500/15 text-emerald-300';

    return (
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="dossier-title"
        className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4"
      >
        <div
          id="violation-dossier-printable"
          className="w-full max-w-3xl max-h-[90vh] overflow-y-auto hud-scroll bg-[#060d1b] border border-cyan-400/40 rounded-md shadow-2xl text-slate-100"
        >
          {/* Modal Header */}
          <div className="px-6 py-4 border-b border-cyan-500/25 flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono text-cyan-300 uppercase tracking-wider">
                  AEGIS-SAR // MED-EAST ORBITAL COMMAND · LIVE TARGET DOSSIER
                </span>
                <span
                  className={`px-1.5 py-0.5 text-[10px] font-mono font-semibold rounded border ${riskBadgeClass}`}
                >
                  {financialLiability.riskTier} RISK
                </span>
              </div>
              <h2 id="dossier-title" className="text-lg font-bold text-slate-100 mt-1">
                {liveSnapshot.targetLabel}
              </h2>
              <p className="text-xs font-mono text-slate-400 mt-1">
                {liveSnapshot.targetSubtitle} · {liveSnapshot.lat.toFixed(4)}°N,{' '}
                {liveSnapshot.lon.toFixed(4)}°E · UTC {new Date().toISOString().slice(0, 19)}Z
              </p>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close Violation Dossier"
              className="no-print p-1.5 rounded border border-slate-700 text-slate-400 hover:text-slate-100 hover:border-cyan-400/50 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 space-y-5 text-xs">
            {/* Top 4 Telemetry Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
              <div className="border border-slate-800 rounded p-2.5 bg-[#040914]">
                <div className="text-[10px] text-slate-400">TARGET / MMSI</div>
                <div className="text-slate-100 font-semibold mt-0.5 truncate">{vessel.name}</div>
                <div className="text-[10px] text-cyan-300">
                  MMSI {vessel.mmsi} · {liveSnapshot.isDarkCutoff ? 'DARK CUTOFF' : 'LIVE AIS'}
                </div>
              </div>
              <div className="border border-slate-800 rounded p-2.5 bg-[#040914]">
                <div className="text-[10px] text-slate-400">AZIMUTH DOPPLER Δx</div>
                <div className="text-slate-100 font-semibold mt-0.5">
                  {dopplerPhysics.azimuthShiftM >= 0 ? '+' : ''}
                  {dopplerPhysics.azimuthShiftM.toFixed(1)} m
                </div>
                <div className="text-[10px] text-amber-300">
                  Vr {dopplerPhysics.radialVelocityMs.toFixed(2)} m/s · Wake{' '}
                  {dopplerPhysics.wakeSeparationM.toFixed(0)} m
                </div>
              </div>
              <div className="border border-slate-800 rounded p-2.5 bg-[#040914]">
                <div className="text-[10px] text-slate-400">3-BUOY METOCEAN &amp; Kp</div>
                <div className="text-slate-100 font-semibold mt-0.5">
                  {localMetocean.windSpeedKts.toFixed(1)} kts {localMetocean.windDirectionCardinal}
                </div>
                <div className="text-[10px] text-emerald-400">
                  Cur {localMetocean.currentSpeedKts.toFixed(2)} kts · Kp {weather.kpIndex.toFixed(1)}
                </div>
              </div>
              <div className="border border-slate-800 rounded p-2.5 bg-[#040914]">
                <div className="text-[10px] text-slate-400">SUBSEA CABLE RISK</div>
                <div
                  className={`font-semibold mt-0.5 ${
                    cableRisk.anchorDragRiskScore >= 70
                      ? 'text-rose-400'
                      : cableRisk.anchorDragRiskScore >= 40
                        ? 'text-amber-300'
                        : 'text-emerald-400'
                  }`}
                >
                  {cableRisk.anchorDragRiskScore}/100 ({cableRisk.cableName})
                </div>
                <div className="text-[10px] text-slate-400">
                  Sep {cableRisk.distanceKm.toFixed(2)} km · {cableRisk.capacityTbps} Tbps
                </div>
              </div>
            </div>

            {/* Section 1: AIS Dark-Gap Watchdog & 360° Reachability Envelope */}
            <div className="space-y-2">
              <h3 className="text-[11px] font-mono uppercase tracking-wider text-cyan-300">
                1. AIS Dark-Gap Watchdog &amp; 360° Evasive Reachability Envelope
              </h3>
              {darkEnvelope ? (
                <div className="rounded border border-rose-500/40 bg-rose-500/10 p-3 space-y-2 font-mono text-[11px]">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-rose-200 font-semibold">
                    <span>
                      DARK VESSEL (AIS CUTOFF) — {darkEnvelope.gapMinutes.toFixed(1)} MIN SILENCE
                      {darkEnvelope.isSimulated ? ' [SIMULATED BLACKOUT]' : ' [LIVE WATCHDOG]'}
                    </span>
                    <span>
                      Rmax = {darkEnvelope.reachabilityRadiusKm.toFixed(2)} km (Ø{' '}
                      {darkEnvelope.reachabilityDiameterKm.toFixed(1)} km)
                    </span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[10px] text-slate-200">
                    <div>
                      LKP: {darkEnvelope.lkpLat.toFixed(4)}°N, {darkEnvelope.lkpLon.toFixed(4)}°E
                    </div>
                    <div>
                      Current-Shifted Center: {darkEnvelope.reachabilityCenterLat.toFixed(4)}°N,{' '}
                      {darkEnvelope.reachabilityCenterLon.toFixed(4)}°E
                    </div>
                    <div>
                      Vmax Envelope: {darkEnvelope.maxSpeedKts.toFixed(1)} kts (90°–180° evasion)
                    </div>
                  </div>
                  {darkEnvelope.intersectingCables.length > 0 ? (
                    <div className="text-[10px] text-rose-300 border-t border-rose-500/30 pt-1.5">
                      INFRASTRUCTURE THREAT: 360° disk intersects{' '}
                      {darkEnvelope.intersectingCables
                        .map(
                          (c) =>
                            `${c.cableName} (${c.capacityTbps} Tbps, ${c.distanceKm.toFixed(2)} km)`
                        )
                        .join(' · ')}
                    </div>
                  ) : (
                    <div className="text-[10px] text-slate-300 border-t border-rose-500/30 pt-1.5">
                      Nearest Subsea Corridor: {darkEnvelope.nearestCable.cableName} (
                      {darkEnvelope.nearestCable.distanceKm.toFixed(2)} km clearance)
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-slate-300 leading-relaxed">
                  Target is actively broadcasting continuous AIS telemetry (gap{' '}
                  {(vessel.aisGapHours * 60).toFixed(1)} min, threshold &gt; 10.0 min open-water at{' '}
                  &gt; 4.0 kts). Live SGP4 Doppler offset computes Δx ={' '}
                  {dopplerPhysics.azimuthShiftM.toFixed(1)} m under{' '}
                  {dopplerPhysics.satelliteName} ({dopplerPhysics.incidenceAngleDeg.toFixed(1)}°
                  incidence).
                </p>
              )}
            </div>

            {/* Section 2: Autonomous SGP4 Next-Pass Intercept & Tasking */}
            <div className="space-y-2">
              <h3 className="text-[11px] font-mono uppercase tracking-wider text-cyan-300">
                2. Autonomous SGP4 Next-Pass Intercept &amp; SAR Swath Capture
              </h3>
              {sgp4Intercept ? (
                <div className="rounded border border-slate-800 bg-[#040914] p-3 font-mono text-[11px] space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-slate-100 font-semibold">
                      {sgp4Intercept.satelliteName} (NORAD {sgp4Intercept.noradId}) ·{' '}
                      {sgp4Intercept.bandLabel} · {sgp4Intercept.orbitDirection}
                    </span>
                    <span className="text-cyan-300 font-semibold">
                      T-{sgp4Intercept.countdownFormatted} · Capture Prob{' '}
                      {sgp4Intercept.captureProbabilityPct.toFixed(1)}%
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 flex flex-wrap gap-4">
                    <span>AOS UTC: {sgp4Intercept.interceptUtc}</span>
                    <span>Swath Width: {sgp4Intercept.swathWidthKm} km</span>
                    <span>
                      Disk Ø vs Swath: {sgp4Intercept.evasiveDiskDiameterKm.toFixed(1)} km /{' '}
                      {sgp4Intercept.swathWidthKm} km
                    </span>
                    <span>Closest Track: {sgp4Intercept.closestApproachKm.toFixed(1)} km</span>
                  </div>
                  {displayedTasks.length > 0 && (
                    <div className="border-t border-slate-800 pt-2 space-y-1">
                      <div className="text-[10px] text-emerald-400 uppercase">
                        Queued SAR Acquisition Orders ({displayedTasks.length})
                      </div>
                      {displayedTasks.map((task) => (
                        <div
                          key={task.taskId}
                          className="text-[10px] text-slate-300 flex flex-wrap justify-between gap-2"
                        >
                          <span>
                            [{task.taskId}] {task.satelliteName} → {task.vesselName} (MMSI{' '}
                            {task.mmsi})
                          </span>
                          <span className="text-cyan-300">
                            {task.captureProbabilityPct.toFixed(1)}% · {task.aosUtc.slice(11, 19)}Z
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-slate-400 font-mono text-[11px]">
                  Awaiting SGP4 orbital TLE propagation.
                </p>
              )}
            </div>

            {/* Section 3: Live Lagrangian Oil Spill Backtracking & Forward Drift */}
            <div className="space-y-2">
              <h3 className="text-[11px] font-mono uppercase tracking-wider text-cyan-300">
                3. Live Open-Meteo 3-Buoy Spill Backtracking &amp; Landfall Forecast
              </h3>
              {oilSimulation ? (
                <div className="rounded border border-amber-500/35 bg-amber-500/10 p-3 font-mono text-[11px] space-y-1.5">
                  <div className="flex flex-wrap justify-between gap-2 text-amber-200 font-semibold">
                    <span>{oilSimulation.sourceLabel}</span>
                    <span>
                      {oilSimulation.slickAreaKm2.toFixed(2)} km² · ~
                      {oilSimulation.estimatedVolumeBarrels.toLocaleString()} bbl
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[10px] text-slate-200">
                    <div>
                      Backtrack Origin (T-{oilSimulation.releaseHoursAgo}h):{' '}
                      {oilSimulation.originLat.toFixed(4)}°N, {oilSimulation.originLon.toFixed(4)}°E
                    </div>
                    <div>Release UTC: {oilSimulation.originTimeUtc}</div>
                    <div>
                      Drift Vector: {oilSimulation.driftBearingDeg.toFixed(0)}°T @{' '}
                      {oilSimulation.driftSpeedKts.toFixed(2)} kts (Wind{' '}
                      {oilSimulation.windContributionKts.toFixed(2)} + Cur{' '}
                      {oilSimulation.currentContributionKts.toFixed(2)} kts)
                    </div>
                    <div className="text-amber-300">
                      Landfall Forecast: {oilSimulation.impactZoneName} ·{' '}
                      {oilSimulation.coastlineImpactEtaHours !== null
                        ? `ETA ${oilSimulation.coastlineImpactEtaHours.toFixed(1)}h`
                        : 'Offshore Advection (>72h)'}
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-slate-400 font-mono text-[11px]">
                  No active slick seeded for this target. Use DRIFT &amp; COST → [DROP SLICK AT
                  VESSEL] or [EVALUATE SAR SCENE] to compute live 3-buoy backtracking and landfall
                  ETA.
                </p>
              )}
            </div>

            {/* Section 4: Live USD Economic & Environmental Liability */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-[11px] font-mono uppercase tracking-wider text-cyan-300">
                  4. Live USD Economic, Cable &amp; Environmental Liability Assessment
                </h3>
                <span className="font-mono text-amber-300 font-semibold">
                  Subsea Cable Exposure: ${financialLiability.cableExposureM.toFixed(2)}M
                </span>
              </div>

              <table className="w-full font-mono border border-slate-800">
                <thead className="bg-slate-900 text-slate-400 text-[10px]">
                  <tr>
                    <th className="text-left py-2 px-3">LIABILITY COMPONENT</th>
                    <th className="text-right py-2 px-3">MIN ($M)</th>
                    <th className="text-right py-2 px-3">MEDIAN ($M)</th>
                    <th className="text-right py-2 px-3">MAX ($M)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200">
                  <tr>
                    <td className="py-2 px-3 font-sans">Shoreline Cleanup &amp; Skimming</td>
                    <td className="py-2 px-3 text-right">
                      ${financialLiability.shorelineCleanup.minM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right text-cyan-300 font-semibold">
                      ${financialLiability.shorelineCleanup.medianM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right">
                      ${financialLiability.shorelineCleanup.maxM.toFixed(2)}M
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-sans">
                      Subsea Cable / Port &amp; Suez Approach Disruption
                    </td>
                    <td className="py-2 px-3 text-right">
                      ${financialLiability.portSuezDisruption.minM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right text-cyan-300 font-semibold">
                      ${financialLiability.portSuezDisruption.medianM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right">
                      ${financialLiability.portSuezDisruption.maxM.toFixed(2)}M
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-sans">Marine &amp; Coastal Habitat Loss</td>
                    <td className="py-2 px-3 text-right">
                      ${financialLiability.marineHabitatLoss.minM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right text-cyan-300 font-semibold">
                      ${financialLiability.marineHabitatLoss.medianM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right">
                      ${financialLiability.marineHabitatLoss.maxM.toFixed(2)}M
                    </td>
                  </tr>
                  <tr className="bg-slate-900/80 font-bold">
                    <td className="py-2 px-3 font-sans text-slate-100">
                      Total Live Claim Range ({financialLiability.iterations.toLocaleString()}{' '}
                      runs)
                    </td>
                    <td className="py-2 px-3 text-right">
                      ${financialLiability.totalEstimatedLiability.minM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right text-rose-400">
                      ${financialLiability.totalEstimatedLiability.medianM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right">
                      ${financialLiability.totalEstimatedLiability.maxM.toFixed(2)}M
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="no-print px-6 py-4 border-t border-cyan-500/20 flex items-center justify-end gap-2.5 bg-[#040812]/80">
            <button
              type="button"
              onClick={handleDownloadJson}
              className="px-3.5 py-2 text-xs font-mono rounded border border-slate-600 text-slate-200 hover:border-cyan-400/50 hover:text-cyan-200 flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>EXPORT LIVE JSON</span>
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 text-xs font-mono font-semibold rounded bg-cyan-500/25 hover:bg-cyan-500/35 border border-cyan-400/60 text-cyan-100 flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>PRINT / SAVE PDF</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="dossier-title"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        id="violation-dossier-printable"
        className="w-full max-w-3xl max-h-[90vh] overflow-y-auto hud-scroll bg-[#060d1b] border border-cyan-400/40 rounded-md shadow-2xl text-slate-100"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-cyan-500/25 flex items-start justify-between gap-4">
          <div>
            <div className="text-[11px] font-mono text-cyan-300 uppercase tracking-wider">
              AEGIS-SAR // MED-EAST ORBITAL COMMAND · FORENSIC LIABILITY DOSSIER
            </div>
            <h2 id="dossier-title" className="text-lg font-bold text-slate-100 mt-1">
              {incident.caseCode}: {incident.title}
            </h2>
            <p className="text-xs font-mono text-slate-400 mt-1">
              Acquisition: {sar.acquisitionTimeUtc} · Threat Score: {incident.threatScore}/100 ·
              Sector: Eastern Mediterranean (Egypt EEZ)
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close Violation Dossier"
            className="no-print p-1.5 rounded border border-slate-700 text-slate-400 hover:text-slate-100 hover:border-cyan-400/50 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5 text-xs">
          {/* Vessel & Telemetry Metadata */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
            <div className="border border-slate-800 rounded p-2.5 bg-[#040914]">
              <div className="text-[10px] text-slate-400">VESSEL / MMSI</div>
              <div className="text-slate-100 font-semibold mt-0.5 truncate">{vessel.name}</div>
              <div className="text-[10px] text-cyan-300">{vessel.mmsi}</div>
            </div>
            <div className="border border-slate-800 rounded p-2.5 bg-[#040914]">
              <div className="text-[10px] text-slate-400">DIMENSIONS / FLAG</div>
              <div className="text-slate-100 font-semibold mt-0.5">
                {vessel.lengthM}m × {vessel.beamM}m
              </div>
              <div className="text-[10px] text-slate-400">
                IMO {vessel.imo} · {vessel.flag}
              </div>
            </div>
            <div className="border border-slate-800 rounded p-2.5 bg-[#040914]">
              <div className="text-[10px] text-slate-400">SAR SENSOR &amp; Δx</div>
              <div className="text-slate-100 font-semibold mt-0.5">
                {sar.calculatedTrueSpeedKts.toFixed(1)} kts
              </div>
              <div className="text-[10px] text-amber-300">
                Azimuth Shift {sar.azimuthDisplacementM}m
              </div>
            </div>
            <div className="border border-slate-800 rounded p-2.5 bg-[#040914]">
              <div className="text-[10px] text-slate-400">ENVIRONMENT &amp; Kp</div>
              <div className="text-slate-100 font-semibold mt-0.5">
                {weather.windSpeedKts} kts {weather.windDirectionCardinal}
              </div>
              <div className="text-[10px] text-emerald-400">
                Kp {weather.kpIndex.toFixed(1)} ({weather.kpStatus})
              </div>
            </div>
          </div>

          {/* Executive Summary & Causal Chain */}
          <div className="space-y-2">
            <h3 className="text-[11px] font-mono uppercase tracking-wider text-cyan-300">
              1. Evidentiary Summary &amp; Attribution Chain
            </h3>
            <p className="text-slate-200 leading-relaxed">{incident.summary}</p>
            <ul className="space-y-1.5 pt-1">
              {incident.causalChain.map((item, idx) => (
                <li key={idx} className="flex gap-2 text-slate-300">
                  <span className="font-mono text-cyan-400">[{idx + 1}]</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Monte Carlo Financial & Environmental Exposure */}
          {drift && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-[11px] font-mono uppercase tracking-wider text-cyan-300">
                  2. Bayesian Attribution &amp; Monte Carlo Liability Assessment
                </h3>
                <span className="font-mono text-rose-400 font-semibold">
                  P(Vessel | Slick) = {drift.bayesianScorePct.toFixed(1)}%
                </span>
              </div>

              <table className="w-full font-mono border border-slate-800">
                <thead className="bg-slate-900 text-slate-400 text-[10px]">
                  <tr>
                    <th className="text-left py-2 px-3">LIABILITY COMPONENT</th>
                    <th className="text-right py-2 px-3">MIN ($M)</th>
                    <th className="text-right py-2 px-3">MEDIAN ($M)</th>
                    <th className="text-right py-2 px-3">MAX ($M)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200">
                  <tr>
                    <td className="py-2 px-3 font-sans">Shoreline Cleanup &amp; Skimming</td>
                    <td className="py-2 px-3 text-right">
                      ${drift.costModel.shorelineCleanup.minM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right text-cyan-300 font-semibold">
                      ${drift.costModel.shorelineCleanup.medianM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right">
                      ${drift.costModel.shorelineCleanup.maxM.toFixed(2)}M
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-sans">Port &amp; Suez Canal Approach Disruption</td>
                    <td className="py-2 px-3 text-right">
                      ${drift.costModel.portSuezDisruption.minM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right text-cyan-300 font-semibold">
                      ${drift.costModel.portSuezDisruption.medianM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right">
                      ${drift.costModel.portSuezDisruption.maxM.toFixed(2)}M
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-sans">Marine &amp; Coastal Habitat Loss</td>
                    <td className="py-2 px-3 text-right">
                      ${drift.costModel.marineHabitatLoss.minM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right text-cyan-300 font-semibold">
                      ${drift.costModel.marineHabitatLoss.medianM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right">
                      ${drift.costModel.marineHabitatLoss.maxM.toFixed(2)}M
                    </td>
                  </tr>
                  <tr className="bg-slate-900/80 font-bold">
                    <td className="py-2 px-3 font-sans text-slate-100">
                      Total Estimated Claim Range ({drift.costModel.iterations.toLocaleString()} runs)
                    </td>
                    <td className="py-2 px-3 text-right">
                      ${drift.costModel.totalEstimatedLiability.minM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right text-rose-400">
                      ${drift.costModel.totalEstimatedLiability.medianM.toFixed(2)}M
                    </td>
                    <td className="py-2 px-3 text-right">
                      ${drift.costModel.totalEstimatedLiability.maxM.toFixed(2)}M
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="no-print px-6 py-4 border-t border-cyan-500/20 flex items-center justify-end gap-2.5 bg-[#040812]/80">
          <button
            type="button"
            onClick={handleDownloadJson}
            className="px-3.5 py-2 text-xs font-mono rounded border border-slate-600 text-slate-200 hover:border-cyan-400/50 hover:text-cyan-200 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>EXPORT JSON</span>
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-2 text-xs font-mono font-semibold rounded bg-cyan-500/25 hover:bg-cyan-500/35 border border-cyan-400/60 text-cyan-100 flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>PRINT / SAVE PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
};
