import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BottomControlDeck } from './components/BottomControlDeck';
import { IncidentTriagePanel } from './components/IncidentTriagePanel';
import { MissionBriefingModal } from './components/MissionBriefingModal';
import { TacticalMap } from './components/TacticalMap';
import { TacticalNotificationFeed } from './components/TacticalNotificationFeed';
import { TargetInspectorPanel } from './components/TargetInspectorPanel';
import { TopTelemetryBar } from './components/TopTelemetryBar';
import { ViolationDossierModal } from './components/ViolationDossierModal';
import {
  AisConnectionStatus,
  connectServerAisStream,
  reconnectServerAisStream,
} from './services/aisStreamService';
import {
  evaluateHistoricalReplayAtMinute,
  fetchHistoricalScenario,
  getFirstValidHistoricalQuicklook,
  getHistoricalScenarioMeta,
} from './services/historicalService';
import {
  checkNasaGibsAvailability,
  FALLBACK_EONET_EVENTS,
  FALLBACK_METOCEAN_BUOYS,
  fetchNasaAsfScenes,
  fetchNasaEonetEvents,
  fetchSpaceWeatherLive,
  fetchThreeBuoyMetocean,
} from './services/liveFeedsService';
import {
  DEFAULT_SAR_TLE_CATALOG,
  fetchLiveNoradTles,
  propagateSarSatellites,
} from './services/orbitalPropagationService';
import {
  computeDarkEnvelope,
  computeLiveForensicSnapshot,
  computeLiveOilSpillSimulation,
  computeSubseaCableProximityAlerts,
  evaluateCableThreats,
  formatBlackoutDuration,
} from './services/surveillanceForensicsService';
import {
  getFallbackAsfScenes,
  getIncidentById,
  getIncidents,
  getSarSwaths,
  getShippingLanes,
  getSlickEnsembleAtOffset,
  getSubseaCables,
  getVesselById,
  getVessels,
  getWeatherState,
} from './services/telemetryService';
import {
  AsfSarScene,
  BaseMapId,
  DarkEnvelopeState,
  DarkVesselAlert,
  EonetEvent,
  HistoricalTimelinePayload,
  HudMode,
  Incident,
  IncidentFilter,
  InspectorTab,
  LayerVisibility,
  LiveFeedDiagnostic,
  MetoceanBuoy,
  QueuedSarTask,
  SatelliteGroundState,
  SatelliteTleRecord,
  ScenarioId,
  Sgp4InterceptAssessment,
  SimulatedBlackoutRecord,
  Vessel,
  WeatherState,
} from './types/telemetry';

export default function App() {
  // Forensic Case Study Fleet (used exclusively in Forensic Case Lab mode)
  const [simulatedVessels] = useState<Vessel[]>(() => getVessels());
  const allIncidents = useMemo(() => getIncidents('all'), []);
  const subseaCables = useMemo(() => getSubseaCables(), []);
  const shippingLanes = useMemo(() => getShippingLanes(), []);
  const sarSwaths = useMemo(() => getSarSwaths(), []);

  // Live Feeds State (with immediate calibrated fallbacks)
  const [weather, setWeather] = useState<WeatherState>(() => getWeatherState());
  const [buoys, setBuoys] = useState<MetoceanBuoy[]>(() => FALLBACK_METOCEAN_BUOYS);
  const [eonetEvents, setEonetEvents] = useState<EonetEvent[]>(() => FALLBACK_EONET_EVENTS);
  const [asfScenes, setAsfScenes] = useState<AsfSarScene[]>(() => getFallbackAsfScenes());
  const [tleCatalog, setTleCatalog] = useState<SatelliteTleRecord[]>(() => DEFAULT_SAR_TLE_CATALOG);
  const [satellites, setSatellites] = useState<SatelliteGroundState[]>(() =>
    propagateSarSatellites(new Date(), DEFAULT_SAR_TLE_CATALOG)
  );

  // Real Live AIS Stream State (via server-side /api/ais/stream SSE proxy)
  const [liveAisVessels, setLiveAisVessels] = useState<Vessel[]>([]);
  const [aisStatus, setAisStatus] = useState<AisConnectionStatus>('connecting');
  const [aisError, setAisError] = useState<string>('');
  const [relayAttemptNonce, setRelayAttemptNonce] = useState<number>(0);

  // 7-Endpoint Diagnostic Telemetry State
  const [feedDiagnostics, setFeedDiagnostics] = useState<LiveFeedDiagnostic[]>(() => {
    const ts = new Date().toISOString();
    return [
      {
        id: 'gibs',
        label: '1. NASA GIBS Daily Imagery',
        endpoint: 'gibs.earthdata.nasa.gov (default/default)',
        status: 'CACHED FALLBACK',
        lastSyncUtc: ts,
        rawSummary: 'Probing VIIRS SNPP Latest Mosaic...',
      },
      {
        id: 'eonet',
        label: '2. NASA EONET Live Earth Events',
        endpoint: '/api/telemetry/eonet -> eonet.gsfc.nasa.gov',
        status: 'CACHED FALLBACK',
        lastSyncUtc: ts,
        rawSummary: 'Probing active Earth events...',
      },
      {
        id: 'donki_noaa',
        label: '3. NASA DONKI & NOAA Planetary Kp',
        endpoint: '/api/telemetry/space-weather -> DONKI + SWPC',
        status: 'CACHED FALLBACK',
        lastSyncUtc: ts,
        rawSummary: 'Probing space weather Kp...',
      },
      {
        id: 'norad_tle',
        label: '4. NORAD Live Orbital TLEs',
        endpoint: '/api/telemetry/norad-tle -> CelesTrak / NORAD',
        status: 'CACHED FALLBACK',
        lastSyncUtc: ts,
        rawSummary: 'Probing Sentinel-1A, 1C & NISAR TLEs...',
      },
      {
        id: 'open_meteo',
        label: '5. Open-Meteo 3-Buoy Marine & Wind',
        endpoint: '/api/telemetry/metocean -> open-meteo.com',
        status: 'CACHED FALLBACK',
        lastSyncUtc: ts,
        rawSummary: 'Probing Alexandria, Damietta & Port Said...',
      },
      {
        id: 'asf_daac',
        label: '6. NASA ASF DAAC SAR Catalog',
        endpoint: '/api/telemetry/asf-sar -> api.daac.asf.alaska.edu',
        status: 'CACHED FALLBACK',
        lastSyncUtc: ts,
        rawSummary: 'Probing Sentinel-1 & NISAR scenes...',
      },
      {
        id: 'ais_live',
        label: '7. AISStream.io Real-Time Vessels',
        endpoint: '/api/ais/stream -> wss://stream.aisstream.io',
        status: 'CACHED FALLBACK',
        lastSyncUtc: ts,
        rawSummary: 'Probing server-side AIS proxy...',
      },
    ];
  });

  // Default to COASTAL SURVEILLANCE Mode on load
  const [baseMap, setBaseMap] = useState<BaseMapId>('satellite');
  const [hudMode, setHudMode] = useState<HudMode>('surveillance');
  const [hudMinimized, setHudMinimized] = useState<boolean>(false);
  const [briefingOpen, setBriefingOpen] = useState<boolean>(true);
  const [incidentFilter, setIncidentFilter] = useState<IncidentFilter>('all');
  const [selectedIncidentId, setSelectedIncidentId] = useState<string>(
    allIncidents[0]?.id ?? 'inc-01'
  );
  const [selectedVesselId, setSelectedVesselId] = useState<string | null>(null);
  const [selectedAsfSceneId, setSelectedAsfSceneId] = useState<string | null>(null);
  const [inspectTargetMode, setInspectTargetMode] = useState<'vessel' | 'sar_footprint'>('vessel');
  const [inspectorTab, setInspectorTab] = useState<InspectorTab>('behavior');
  const [dossierOpen, setDossierOpen] = useState<boolean>(false);

  // Autonomous Coastal Surveillance Watchdog, SAR Tasking & Live Oil Simulation State
  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  const [simulatedBlackouts, setSimulatedBlackouts] = useState<
    Record<string, SimulatedBlackoutRecord>
  >({});
  const [queuedSarTasks, setQueuedSarTasks] = useState<QueuedSarTask[]>([]);
  const [oilOverlayDismissed, setOilOverlayDismissed] = useState<boolean>(false);
  const [liveOilAnchor, setLiveOilAnchor] = useState<{
    id: string;
    label: string;
    anchorType: 'vessel' | 'sar_footprint';
    lat: number;
    lon: number;
    releaseHoursAgo: number;
  } | null>(null);

  // Automated Tactical Notification Feed (30-Minute AIS Blackout Rule)
  const [alertsOpen, setAlertsOpen] = useState<boolean>(false);
  const [tacticalAlerts, setTacticalAlerts] = useState<DarkVesselAlert[]>([]);
  const [toastAlertId, setToastAlertId] = useState<string | null>(null);
  const dispatchedEpisodesRef = useRef<Set<string>>(new Set());

  // Layer Visibility Matrix
  const [layers, setLayers] = useState<LayerVisibility>({
    nauticalLanes: true,
    subseaCables: true,
    sarSwaths: true,
    sarBackscatter: false,
    searchCones: true,
    oilDriftEnsemble: true,
  });

  // Time-Machine Scrubber State (-48h to +24h, T=0 default)
  const [timeOffsetHours, setTimeOffsetHours] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // Scenario Selector & 24-Hour Historical Replay State
  const [activeScenarioId, setActiveScenarioId] = useState<ScenarioId>('live');
  const [historicalPayload, setHistoricalPayload] = useState<HistoricalTimelinePayload | null>(null);
  const [historicalLoading, setHistoricalLoading] = useState<boolean>(false);
  const [historicalMinute, setHistoricalMinute] = useState<number>(0);
  const [historicalPlaying, setHistoricalPlaying] = useState<boolean>(false);
  const activeScenarioRef = useRef<ScenarioId>('live');

  // Map Camera Fly-To Request
  const [flyToRequest, setFlyToRequest] = useState<{
    lat: number;
    lon: number;
    zoom: number;
    nonce: number;
  } | null>(null);

  const updateDiagnostic = useCallback(
    (
      id: LiveFeedDiagnostic['id'],
      status: LiveFeedDiagnostic['status'],
      rawSummary: string
    ) => {
      const nowIso = new Date().toISOString();
      setFeedDiagnostics((prev) =>
        prev.map((d) =>
          d.id === id ? { ...d, status, rawSummary, lastSyncUtc: nowIso } : d
        )
      );
    },
    []
  );

  // Sync all NASA / NORAD / NOAA / Open-Meteo / ASF live feeds via Express backend
  const syncAllLiveFeeds = useCallback(
    (forceRefresh = false) => {
      checkNasaGibsAvailability().then((res) => {
        updateDiagnostic('gibs', res.status, res.rawSummary);
      });

      fetchNasaEonetEvents(forceRefresh).then((res) => {
        setEonetEvents(res.events);
        updateDiagnostic('eonet', res.status, res.rawSummary);
      });

      fetchSpaceWeatherLive(forceRefresh).then((res) => {
        setWeather((prev) => ({ ...prev, ...res.weather }));
        updateDiagnostic('donki_noaa', res.status, res.rawSummary);
      });

      fetchLiveNoradTles(forceRefresh).then((res) => {
        setTleCatalog(res.records);
        setSatellites(propagateSarSatellites(new Date(), res.records));
        updateDiagnostic('norad_tle', res.status, res.rawSummary);
      });

      fetchThreeBuoyMetocean(forceRefresh).then((res) => {
        setBuoys(res.buoys);
        setWeather((prev) => ({ ...prev, ...res.aggregate }));
        updateDiagnostic('open_meteo', res.status, res.rawSummary);
      });

      fetchNasaAsfScenes(forceRefresh).then((res) => {
        setAsfScenes(res.scenes);
        updateDiagnostic('asf_daac', res.status, res.rawSummary);
      });
    },
    [updateDiagnostic]
  );

  useEffect(() => {
    syncAllLiveFeeds(false);
  }, [syncAllLiveFeeds]);

  // 1-Second Real-Time SGP4 Orbital Motion & Dark-Gap Watchdog Clock
  useEffect(() => {
    const timer = window.setInterval(() => {
      const current = new Date();
      setNowMs(current.getTime());
      setSatellites(propagateSarSatellites(current, tleCatalog));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [tleCatalog]);

  // Connect to Built-In Server-Side AISStream SSE Proxy (/api/ais/stream)
  useEffect(() => {
    const cleanup = connectServerAisStream(
      (vessels) => {
        setLiveAisVessels(vessels);
        if (vessels.length > 0) {
          updateDiagnostic(
            'ais_live',
            '200 OK',
            `${vessels.length} real AIS vessels in Med-East sector`
          );
        }
      },
      (info) => {
        setAisStatus(info.status);
        setAisError(info.errorMessage || '');
        if (info.status === 'connected') {
          updateDiagnostic(
            'ais_live',
            '200 OK',
            info.vesselCount > 0
              ? `${info.vesselCount} real AIS vessels (server proxy)`
              : 'WebSocket open · awaiting first PositionReport'
          );
        } else if (info.status === 'needs_key') {
          updateDiagnostic(
            'ais_live',
            'CACHED FALLBACK',
            'Server AISSTREAM_API_KEY not configured'
          );
        } else if (info.status === 'error') {
          updateDiagnostic(
            'ais_live',
            'CACHED FALLBACK',
            info.errorMessage || 'AISStream connection error'
          );
        } else {
          updateDiagnostic('ais_live', 'CACHED FALLBACK', `AIS status: ${info.status}`);
        }
      }
    );
    return cleanup;
  }, [relayAttemptNonce, updateDiagnostic]);

  // Real-Time AIS Dark-Gap Watchdog (30-Minute Rule):
  // - <= 30m: vessel stays GREEN ('legal') with a predictive green reachability envelope
  // - > 30m: escalates to RED ('dark'), intensifies reachability envelope, and triggers alert feed
  const darkEnvelopes = useMemo<DarkEnvelopeState[]>(() => {
    return liveAisVessels
      .map((v) =>
        computeDarkEnvelope(
          v,
          nowMs,
          simulatedBlackouts,
          subseaCables,
          buoys,
          weather,
          v.id === selectedVesselId
        )
      )
      .filter((env): env is DarkEnvelopeState => env !== null);
  }, [liveAisVessels, nowMs, simulatedBlackouts, subseaCables, buoys, weather, selectedVesselId]);

  const darkEnvelopeMap = useMemo(() => {
    const map = new Map<string, DarkEnvelopeState>();
    darkEnvelopes.forEach((env) => map.set(env.vesselId, env));
    return map;
  }, [darkEnvelopes]);

  // Enrich live AIS vessels with real-time cable distance + conditional 30m Dark Cutoff status
  const enrichedLiveVessels = useMemo(() => {
    return liveAisVessels.map((v) => {
      const env = darkEnvelopeMap.get(v.id);
      const nearest = evaluateCableThreats(
        { lat: v.lat, lon: v.lon },
        env ? env.reachabilityRadiusKm : 2.0,
        subseaCables,
        v.sogKts
      ).nearestCable;

      if (env) {
        return {
          ...v,
          lat: env.lkpLat,
          lon: env.lkpLon,
          status: env.isConfirmedDark ? ('dark' as const) : ('legal' as const),
          aisGapHours: Number((env.gapMinutes / 60).toFixed(2)),
          nearestCableName: env.nearestCable.cableName,
          nearestCableDistanceKm: env.nearestCable.distanceKm,
        };
      }

      return {
        ...v,
        nearestCableName: nearest.cableName,
        nearestCableDistanceKm: nearest.distanceKm,
      };
    });
  }, [liveAisVessels, darkEnvelopeMap, subseaCables]);

  // Subsea Cable Proximity Watchdog across all live vessels & dark envelopes (< 3.0 km or slow drag)
  const cableThreatAlerts = useMemo(
    () => computeSubseaCableProximityAlerts(enrichedLiveVessels, darkEnvelopes, subseaCables),
    [enrichedLiveVessels, darkEnvelopes, subseaCables]
  );

  const isHistoricalMode = activeScenarioId !== 'live';

  // Automated Tactical Notification Dispatch when any vessel crosses > 30 minutes silent
  useEffect(() => {
    if (isHistoricalMode) return;

    const confirmed = darkEnvelopes.filter((e) => e.isConfirmedDark);
    const activeByEpisode = new Map(confirmed.map((e) => [e.episodeKey, e]));
    const nowIso = new Date(nowMs).toISOString();

    const newlyTriggered: DarkVesselAlert[] = [];
    confirmed.forEach((env) => {
      if (!dispatchedEpisodesRef.current.has(env.episodeKey)) {
        dispatchedEpisodesRef.current.add(env.episodeKey);
        newlyTriggered.push({
          id: `dark-alert-${Date.now()}-${env.mmsi}-${Math.random().toString(36).slice(2, 6)}`,
          episodeKey: env.episodeKey,
          vesselId: env.vesselId,
          vesselName: env.vesselName,
          mmsi: env.mmsi,
          flag: env.flag,
          vesselType: env.vesselType,
          blackoutDurationMinutes: env.gapMinutes,
          blackoutDurationFormatted: formatBlackoutDuration(env.gapMinutes),
          triggeredAtUtc: nowIso,
          lkpLat: env.lkpLat,
          lkpLon: env.lkpLon,
          reachabilityRadiusKm: env.reachabilityRadiusKm,
          maxSpeedKts: env.maxSpeedKts,
          isSimulated: env.isSimulated,
          acknowledged: false,
          active: true,
        });
      }
    });

    if (newlyTriggered.length > 0) {
      setToastAlertId(newlyTriggered[0].id);
    }

    setTacticalAlerts((prev) => {
      let changed = newlyTriggered.length > 0;
      const updatedExisting = prev.map((alert) => {
        const liveEnv = activeByEpisode.get(alert.episodeKey);
        if (!liveEnv) {
          if (alert.active) {
            changed = true;
            return { ...alert, active: false };
          }
          return alert;
        }
        const nextFormatted = formatBlackoutDuration(liveEnv.gapMinutes);
        if (
          !alert.active ||
          alert.blackoutDurationFormatted !== nextFormatted ||
          alert.reachabilityRadiusKm !== liveEnv.reachabilityRadiusKm
        ) {
          changed = true;
          return {
            ...alert,
            active: true,
            blackoutDurationMinutes: liveEnv.gapMinutes,
            blackoutDurationFormatted: nextFormatted,
            reachabilityRadiusKm: liveEnv.reachabilityRadiusKm,
          };
        }
        return alert;
      });

      if (!changed) return prev;
      return [...newlyTriggered, ...updatedExisting].slice(0, 60);
    });
  }, [darkEnvelopes, isHistoricalMode, nowMs]);

  const activeAlertsCount = useMemo(
    () => tacticalAlerts.filter((a) => a.active).length,
    [tacticalAlerts]
  );
  const unreadAlertsCount = useMemo(
    () => tacticalAlerts.filter((a) => !a.acknowledged).length,
    [tacticalAlerts]
  );
  const latestToastAlert = useMemo(
    () => (toastAlertId ? tacticalAlerts.find((a) => a.id === toastAlertId) ?? null : null),
    [toastAlertId, tacticalAlerts]
  );

  const historicalReplay = useMemo(() => {
    if (!isHistoricalMode || !historicalPayload) return null;
    return evaluateHistoricalReplayAtMinute(historicalPayload, historicalMinute);
  }, [isHistoricalMode, historicalPayload, historicalMinute]);

  // Effective Weather (Open-Meteo Archive wind in historical mode; live 3-buoy in live mode)
  const effectiveWeather = useMemo<WeatherState>(() => {
    if (!historicalReplay || !historicalPayload) return weather;
    return {
      ...weather,
      windSpeedKts: historicalReplay.currentWeather.windSpeedKts,
      windSpeedMs: historicalReplay.currentWeather.windSpeedMs,
      windDirectionDeg: historicalReplay.currentWeather.windDirectionDeg,
      windDirectionCardinal: historicalReplay.currentWeather.windDirectionCardinal,
      metoceanSource:
        historicalPayload.weatherStatus === '200 OK' ? 'OPEN_METEO_LIVE' : 'FALLBACK',
      updatedUtc: historicalReplay.currentWeather.timeIso,
    };
  }, [weather, historicalReplay, historicalPayload]);

  // Real AIS Vessels ONLY in Coastal Surveillance mode; Forensic cases + live AIS in Forensic Lab; Historical tracks in Replay
  const combinedVessels = useMemo(() => {
    if (isHistoricalMode) {
      return historicalReplay?.vesselsAtMinute ?? [];
    }
    if (hudMode === 'surveillance') {
      return enrichedLiveVessels;
    }
    const forensicIncidentVessels = simulatedVessels.filter((v) => Boolean(v.incidentId));
    return [...forensicIncidentVessels, ...enrichedLiveVessels];
  }, [isHistoricalMode, historicalReplay, hudMode, enrichedLiveVessels, simulatedVessels]);

  // Effective ASF SAR Swaths (Real historical NASA ASF swaths vs live catalog)
  const effectiveAsfScenes = useMemo(() => {
    if (isHistoricalMode && historicalPayload) {
      return historicalPayload.sarSwaths;
    }
    return asfScenes;
  }, [isHistoricalMode, historicalPayload, asfScenes]);

  // Earliest upcoming SAR pass from live SGP4 propagation or Historical Pass Countdown
  const nextSatellitePass = useMemo<SatelliteGroundState | undefined>(() => {
    if (isHistoricalMode && historicalPayload && historicalReplay) {
      return {
        id: 'historical-sar-pass',
        noradId: historicalPayload.primarySatelliteName.includes('ENVISAT') ? '27386' : '39634',
        name: historicalPayload.primarySatelliteName,
        bandLabel: 'C-BAND',
        color: '#00F0FF',
        lat: historicalPayload.scenario.lat,
        lon: historicalPayload.scenario.lon,
        altitudeKm: 693,
        velocityKmS: 7.5,
        nextPassSeconds: historicalReplay.sarPassCountdownSeconds,
        nextPassTimeUtc: historicalPayload.primaryPassUtc,
        isLiveTle: true,
        trackSegments: [],
      };
    }
    if (satellites.length === 0) return undefined;
    return [...satellites].sort((a, b) => a.nextPassSeconds - b.nextPassSeconds)[0];
  }, [isHistoricalMode, historicalPayload, historicalReplay, satellites]);

  // Filtered Incidents
  const filteredIncidents = useMemo(() => getIncidents(incidentFilter), [incidentFilter]);

  // Selected Incident & Active Target Vessel (prioritizes selected real AIS vessel or historical suspect)
  const selectedIncident = useMemo(
    () => getIncidentById(selectedIncidentId) ?? allIncidents[0],
    [selectedIncidentId, allIncidents]
  );

  const selectedVessel = useMemo(() => {
    if (isHistoricalMode && historicalReplay && historicalReplay.vesselsAtMinute.length > 0) {
      if (selectedVesselId) {
        const histMatch = historicalReplay.vesselsAtMinute.find((v) => v.id === selectedVesselId);
        if (histMatch) return histMatch;
      }
      return historicalReplay.vesselsAtMinute[0];
    }
    if (selectedVesselId) {
      const liveMatch = enrichedLiveVessels.find((v) => v.id === selectedVesselId);
      if (liveMatch) return liveMatch;
      const simMatch = simulatedVessels.find((v) => v.id === selectedVesselId);
      if (simMatch) return simMatch;
    }
    if (hudMode === 'surveillance' && enrichedLiveVessels.length > 0) {
      return enrichedLiveVessels[0];
    }
    return (
      simulatedVessels.find((v) => v.id === selectedIncident.primaryVesselId) ??
      getVesselById(selectedIncident.primaryVesselId) ??
      simulatedVessels[0]
    );
  }, [
    isHistoricalMode,
    historicalReplay,
    selectedVesselId,
    enrichedLiveVessels,
    simulatedVessels,
    hudMode,
    selectedIncident,
  ]);

  const resolvedAsfSceneId = useMemo(
    () =>
      selectedAsfSceneId ??
      effectiveAsfScenes.find((s) => Boolean(s.browseImageUrl))?.id ??
      effectiveAsfScenes[0]?.id ??
      null,
    [selectedAsfSceneId, effectiveAsfScenes]
  );

  const selectedAsfScene = useMemo(
    () => effectiveAsfScenes.find((s) => s.id === resolvedAsfSceneId),
    [effectiveAsfScenes, resolvedAsfSceneId]
  );

  // Live Open-Meteo 3-Buoy Lagrangian Oil Spill Simulation for Coastal Surveillance
  // Automatically runs for any explicitly clicked ship / SAR footprint OR manual drop anchor
  const liveOilSimulation = useMemo(() => {
    if (isHistoricalMode) {
      return null;
    }
    if (liveOilAnchor) {
      return computeLiveOilSpillSimulation(liveOilAnchor, timeOffsetHours, buoys, weather, nowMs);
    }
    if (hudMode !== 'surveillance' || oilOverlayDismissed) {
      return null;
    }
    if (inspectTargetMode === 'sar_footprint' && selectedAsfScene && selectedAsfScene.footprintCoords.length > 0) {
      const avgLat =
        selectedAsfScene.footprintCoords.reduce((acc, p) => acc + p.lat, 0) /
        selectedAsfScene.footprintCoords.length;
      const avgLon =
        selectedAsfScene.footprintCoords.reduce((acc, p) => acc + p.lon, 0) /
        selectedAsfScene.footprintCoords.length;
      return computeLiveOilSpillSimulation(
        {
          id: `auto-sar-${selectedAsfScene.id}`,
          label: selectedAsfScene.sceneName.slice(0, 22),
          anchorType: 'sar_footprint',
          lat: avgLat,
          lon: avgLon,
          releaseHoursAgo: 6,
        },
        timeOffsetHours,
        buoys,
        weather,
        nowMs
      );
    }
    if (selectedVesselId && selectedVessel) {
      return computeLiveOilSpillSimulation(
        {
          id: `auto-vessel-${selectedVessel.id}`,
          label: selectedVessel.name,
          anchorType: 'vessel',
          lat: selectedVessel.lat,
          lon: selectedVessel.lon,
          releaseHoursAgo: 6,
        },
        timeOffsetHours,
        buoys,
        weather,
        nowMs
      );
    }
    return null;
  }, [
    isHistoricalMode,
    liveOilAnchor,
    hudMode,
    oilOverlayDismissed,
    inspectTargetMode,
    selectedAsfScene,
    selectedVesselId,
    selectedVessel,
    timeOffsetHours,
    buoys,
    weather,
    nowMs,
  ]);

  // Live Forensic Physics, SGP4 Intercept & Financial Liability Snapshot
  const selectedDarkEnvelope = useMemo(
    () => (isHistoricalMode ? null : darkEnvelopeMap.get(selectedVessel.id) ?? null),
    [isHistoricalMode, darkEnvelopeMap, selectedVessel.id]
  );

  const liveForensicSnapshot = useMemo(
    () =>
      computeLiveForensicSnapshot({
        vessel: selectedVessel,
        selectedAsfScene,
        inspectTargetMode,
        darkEnvelope: selectedDarkEnvelope,
        cableProximityAlerts: isHistoricalMode ? [] : cableThreatAlerts,
        oilSimulation: isHistoricalMode ? (historicalReplay?.oilDrift ?? null) : liveOilSimulation,
        timeOffsetHours,
        cables: subseaCables,
        buoys,
        fallbackWeather: effectiveWeather,
        tleCatalog,
        referenceDate: new Date(nowMs),
      }),
    [
      selectedVessel,
      selectedAsfScene,
      inspectTargetMode,
      selectedDarkEnvelope,
      isHistoricalMode,
      cableThreatAlerts,
      historicalReplay,
      liveOilSimulation,
      timeOffsetHours,
      subseaCables,
      buoys,
      effectiveWeather,
      tleCatalog,
      nowMs,
    ]
  );

  // Dynamic Lagrangian Drift Ensembles modulated by live Open-Meteo wind & ocean current
  const activeEnsemble = useMemo(
    () => getSlickEnsembleAtOffset(selectedIncident.id, timeOffsetHours, weather),
    [selectedIncident.id, timeOffsetHours, weather]
  );

  const allOilEnsembles = useMemo(() => {
    return allIncidents
      .filter((inc) => Boolean(inc.driftAttribution))
      .map((inc) => getSlickEnsembleAtOffset(inc.id, timeOffsetHours, weather))
      .filter((e): e is NonNullable<typeof e> => e !== null);
  }, [allIncidents, timeOffsetHours, weather]);

  // Playback Loop for Live Time-Machine Scrubber
  useEffect(() => {
    if (isHistoricalMode || !isPlaying) return;
    const timer = window.setInterval(() => {
      setTimeOffsetHours((prev) => {
        if (prev >= 24) return -48;
        return Number((prev + 0.5).toFixed(1));
      });
    }, 160);
    return () => window.clearInterval(timer);
  }, [isHistoricalMode, isPlaying]);

  // Smooth 24-Hour Historical Replay Playback Loop (15 simulated minutes per second -> +3m / 200ms)
  useEffect(() => {
    if (!isHistoricalMode || !historicalPlaying) return;
    const timer = window.setInterval(() => {
      setHistoricalMinute((prev) => {
        if (prev >= 1439) {
          setHistoricalPlaying(false);
          return 1439;
        }
        return Math.min(1439, prev + 3);
      });
    }, 200);
    return () => window.clearInterval(timer);
  }, [isHistoricalMode, historicalPlaying]);

  const handleReconnectAisRelay = useCallback(() => {
    reconnectServerAisStream()
      .then((info) => {
        if (info) {
          setAisStatus(info.status);
          setAisError(info.errorMessage || '');
        }
      })
      .finally(() => {
        setRelayAttemptNonce((n) => n + 1);
      });
  }, []);

  const handleToggleLayer = useCallback((key: keyof LayerVisibility) => {
    setLayers((prev) => ({ ...prev, [key]: !prev[key] }));
  }, []);

  const handleLocateIncident = useCallback((inc: Incident) => {
    setSelectedVesselId(null);
    setSelectedIncidentId(inc.id);
    setFlyToRequest({
      lat: inc.lat,
      lon: inc.lon,
      zoom: inc.zoomTarget,
      nonce: Date.now(),
    });
  }, []);

  const handleInspectIncident = useCallback((inc: Incident) => {
    setSelectedVesselId(null);
    setSelectedIncidentId(inc.id);
    setHudMode('forensic');
    setHudMinimized(false);
    setLayers((prev) => ({ ...prev, sarBackscatter: true }));
    setFlyToRequest({
      lat: inc.lat,
      lon: inc.lon,
      zoom: inc.zoomTarget,
      nonce: Date.now(),
    });
    if (inc.category === 'oil_spills') {
      setInspectorTab('drift_cost');
    } else if (inc.category === 'subsea_cables') {
      setInspectorTab('sar_lab');
    } else {
      setInspectorTab('behavior');
    }
  }, []);

  const handleSelectIncidentFromMap = useCallback(
    (incId: string) => {
      const inc = getIncidentById(incId);
      if (!inc) return;
      setSelectedVesselId(null);
      setSelectedIncidentId(inc.id);
      if (hudMinimized) setHudMinimized(false);
    },
    [hudMinimized]
  );

  const handleSelectVesselFromMap = useCallback(
    (vesselId: string) => {
      setSelectedVesselId(vesselId);
      setInspectTargetMode('vessel');
      setOilOverlayDismissed(false);
      setLiveOilAnchor(null);
      if (hudMinimized) setHudMinimized(false);
    },
    [hudMinimized]
  );

  const handleSelectLiveVesselFromList = useCallback(
    (vessel: Vessel, flyTo: boolean) => {
      setSelectedVesselId(vessel.id);
      setInspectTargetMode('vessel');
      setOilOverlayDismissed(false);
      setLiveOilAnchor(null);
      if (hudMinimized) setHudMinimized(false);
      if (flyTo) {
        setFlyToRequest({
          lat: vessel.lat,
          lon: vessel.lon,
          zoom: 11,
          nonce: Date.now(),
        });
      }
    },
    [hudMinimized]
  );

  const handleSelectAsfScene = useCallback(
    (sceneId: string, centerMap = false) => {
      setSelectedAsfSceneId(sceneId);
      setInspectTargetMode('sar_footprint');
      setOilOverlayDismissed(false);
      setLiveOilAnchor(null);
      setInspectorTab('sar_lab');
      setLayers((prev) => ({ ...prev, sarSwaths: true }));
      if (hudMinimized) setHudMinimized(false);

      if (centerMap) {
        const scene = asfScenes.find((s) => s.id === sceneId);
        if (scene && scene.footprintCoords.length > 0) {
          const avgLat =
            scene.footprintCoords.reduce((acc, p) => acc + p.lat, 0) /
            scene.footprintCoords.length;
          const avgLon =
            scene.footprintCoords.reduce((acc, p) => acc + p.lon, 0) /
            scene.footprintCoords.length;
          setFlyToRequest({
            lat: avgLat,
            lon: avgLon,
            zoom: 8,
            nonce: Date.now(),
          });
        }
      }
    },
    [asfScenes, hudMinimized]
  );

  const handleSimulateBlackout = useCallback((vessel: Vessel) => {
    setSelectedVesselId(vessel.id);
    setInspectTargetMode('vessel');
    setLayers((prev) => ({ ...prev, searchCones: true, subseaCables: true }));
    setSimulatedBlackouts((prev) => ({
      ...prev,
      [vessel.id]: {
        vesselId: vessel.id,
        triggeredAtMs: Date.now(),
        offsetSeconds: 960, // Start at 16 min (green <30m predictive envelope; escalate past 30m via +15m/+1h)
        lkpLat: vessel.lat,
        lkpLon: vessel.lon,
        lastSogKts: Math.max(5.5, vessel.sogKts),
        lastCogDeg: vessel.cogDeg,
        lastHeadingDeg: vessel.headingDeg,
      },
    }));
  }, []);

  const handleAdvanceBlackout = useCallback((vesselId: string, extraSeconds: number) => {
    setSimulatedBlackouts((prev) => {
      const existing = prev[vesselId];
      if (!existing) return prev;
      return {
        ...prev,
        [vesselId]: {
          ...existing,
          offsetSeconds: existing.offsetSeconds + extraSeconds,
        },
      };
    });
  }, []);

  const handleClearBlackout = useCallback((vesselId: string) => {
    setSimulatedBlackouts((prev) => {
      const next = { ...prev };
      delete next[vesselId];
      return next;
    });
  }, []);

  const handleAcknowledgeAlert = useCallback((alertId: string) => {
    setTacticalAlerts((prev) =>
      prev.map((a) => (a.id === alertId ? { ...a, acknowledged: true } : a))
    );
  }, []);

  const handleAcknowledgeAllAlerts = useCallback(() => {
    setTacticalAlerts((prev) => prev.map((a) => ({ ...a, acknowledged: true })));
  }, []);

  const handleClearResolvedAlerts = useCallback(() => {
    setTacticalAlerts((prev) => prev.filter((a) => a.active));
  }, []);

  const handleLocateAlertVessel = useCallback((alert: DarkVesselAlert) => {
    if (activeScenarioRef.current !== 'live') {
      activeScenarioRef.current = 'live';
      setActiveScenarioId('live');
      setHistoricalPayload(null);
      setHistoricalLoading(false);
    }
    setHudMode('surveillance');
    setHudMinimized(false);
    setSelectedVesselId(alert.vesselId);
    setInspectTargetMode('vessel');
    setInspectorTab('behavior');
    setLayers((prev) => ({ ...prev, searchCones: true, subseaCables: true }));
    setFlyToRequest({
      lat: alert.lkpLat,
      lon: alert.lkpLon,
      zoom: 10,
      nonce: Date.now(),
    });
    setTacticalAlerts((prev) =>
      prev.map((a) => (a.id === alert.id ? { ...a, acknowledged: true } : a))
    );
  }, []);

  const handleQueueSarTask = useCallback(
    (intercept: Sgp4InterceptAssessment, targetVessel: Vessel) => {
      const targetLat = selectedDarkEnvelope?.reachabilityCenterLat ?? targetVessel.lat;
      const targetLon = selectedDarkEnvelope?.reachabilityCenterLon ?? targetVessel.lon;
      const taskId = `TASK-${intercept.noradId}-${targetVessel.mmsi.slice(-4)}`;
      const newTask: QueuedSarTask = {
        taskId,
        targetVesselId: targetVessel.id,
        mmsi: targetVessel.mmsi,
        vesselName: targetVessel.name,
        targetLat,
        targetLon,
        satelliteName: intercept.satelliteName,
        noradId: intercept.noradId,
        bandLabel: intercept.bandLabel,
        swathWidthKm: intercept.swathWidthKm,
        aosUtc: intercept.interceptUtc,
        captureProbabilityPct: intercept.captureProbabilityPct,
        queuedAtUtc: new Date().toISOString(),
        status: 'QUEUED',
      };
      setQueuedSarTasks((prev) => {
        const filtered = prev.filter((t) => t.taskId !== taskId);
        return [newTask, ...filtered];
      });
    },
    [selectedDarkEnvelope]
  );

  const handleTriggerLiveOilSpill = useCallback(
    (anchor: {
      id: string;
      label: string;
      anchorType: 'vessel' | 'sar_footprint';
      lat: number;
      lon: number;
    }) => {
      setLayers((prev) => ({ ...prev, oilDriftEnsemble: true, searchCones: true }));
      setOilOverlayDismissed(false);
      setTimeOffsetHours(0);
      setLiveOilAnchor({
        ...anchor,
        releaseHoursAgo: 6,
      });
    },
    []
  );

  const handleClearLiveOilSpill = useCallback(() => {
    setLiveOilAnchor(null);
    setOilOverlayDismissed(true);
  }, []);

  const handleChangeMode = useCallback((mode: HudMode) => {
    setHudMode(mode);
    if (mode === 'surveillance') {
      setSelectedVesselId(null);
      setLayers((prev) => ({
        ...prev,
        nauticalLanes: true,
        subseaCables: true,
        sarSwaths: true,
        sarBackscatter: false,
      }));
      setFlyToRequest({
        lat: 31.65,
        lon: 31.12,
        zoom: 8,
        nonce: Date.now(),
      });
    } else {
      setSelectedVesselId(null);
      setHudMinimized(false);
      setLayers((prev) => ({
        ...prev,
        sarBackscatter: true,
      }));
    }
  }, []);

  const handleResetTime = useCallback(() => {
    if (isHistoricalMode) {
      setHistoricalPlaying(false);
      setHistoricalMinute(0);
      return;
    }
    setIsPlaying(false);
    setTimeOffsetHours(0);
  }, [isHistoricalMode]);

  const handleSelectScenario = useCallback((scenarioId: ScenarioId) => {
    activeScenarioRef.current = scenarioId;
    setActiveScenarioId(scenarioId);
    setIsPlaying(false);
    setHistoricalPlaying(false);
    setSelectedVesselId(null);
    setSelectedAsfSceneId(null);

    if (scenarioId === 'live') {
      setHistoricalPayload(null);
      setHistoricalLoading(false);
      setHistoricalMinute(0);
      setHudMode('surveillance');
      setLayers((prev) => ({
        ...prev,
        nauticalLanes: true,
        subseaCables: true,
        sarSwaths: true,
        sarBackscatter: false,
        searchCones: true,
        oilDriftEnsemble: true,
      }));
      setFlyToRequest({
        lat: 31.65,
        lon: 31.12,
        zoom: 8,
        nonce: Date.now(),
      });
      return;
    }

    const meta = getHistoricalScenarioMeta(scenarioId);
    setHudMode('surveillance');
    setHistoricalMinute(0);
    setHistoricalPayload(null);
    setHistoricalLoading(true);
    setInspectTargetMode('vessel');
    setLayers((prev) => ({
      ...prev,
      nauticalLanes: true,
      subseaCables: true,
      sarSwaths: true,
      sarBackscatter: true,
      searchCones: true,
      oilDriftEnsemble: true,
    }));

    if (meta) {
      setFlyToRequest({
        lat: meta.lat,
        lon: meta.lon,
        zoom: meta.zoomTarget,
        nonce: Date.now(),
      });
    }

    fetchHistoricalScenario(scenarioId)
      .then((payload) => {
        if (activeScenarioRef.current !== scenarioId) return;
        setHistoricalPayload(payload);
        setHistoricalLoading(false);
        const suspect = payload.vessels.find((v) => v.isSuspect) ?? payload.vessels[0];
        if (suspect) {
          setSelectedVesselId(suspect.id);
        }
        const firstQuicklook = getFirstValidHistoricalQuicklook(payload.sarSwaths);
        if (firstQuicklook) {
          setSelectedAsfSceneId(firstQuicklook.id);
        }
      })
      .catch(() => {
        if (activeScenarioRef.current !== scenarioId) return;
        setHistoricalLoading(false);
      });
  }, []);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#040812] text-slate-100 select-none">
      {/* 1. Edge-to-Edge Full-Screen Map */}
      <TacticalMap
        baseMap={baseMap}
        layers={layers}
        vessels={combinedVessels}
        incidents={allIncidents}
        subseaCables={subseaCables}
        shippingLanes={shippingLanes}
        sarSwaths={sarSwaths}
        asfScenes={effectiveAsfScenes}
        satellites={isHistoricalMode ? [] : satellites}
        buoys={isHistoricalMode ? [] : buoys}
        eonetEvents={isHistoricalMode ? [] : eonetEvents}
        selectedIncidentId={selectedIncident.id}
        selectedVesselId={selectedVessel?.id ?? null}
        selectedAsfSceneId={resolvedAsfSceneId}
        activeEnsemble={!isHistoricalMode && hudMode === 'forensic' ? activeEnsemble : null}
        allOilEnsembles={!isHistoricalMode && hudMode === 'forensic' ? allOilEnsembles : []}
        darkEnvelopes={!isHistoricalMode && hudMode === 'surveillance' ? darkEnvelopes : []}
        cableThreatAlerts={!isHistoricalMode && hudMode === 'surveillance' ? cableThreatAlerts : []}
        liveOilSimulation={!isHistoricalMode && hudMode === 'surveillance' ? liveOilSimulation : null}
        historicalReplay={historicalReplay}
        flyToRequest={flyToRequest}
        hudMinimized={hudMinimized}
        onSelectIncident={handleSelectIncidentFromMap}
        onSelectVessel={handleSelectVesselFromMap}
        onSelectAsfScene={(sceneId) => handleSelectAsfScene(sceneId, false)}
      />

      {/* 2. Top Telemetry Bar */}
      <TopTelemetryBar
        activeScenarioId={activeScenarioId}
        historicalLoading={historicalLoading}
        historicalReplay={historicalReplay}
        historicalPayload={historicalPayload}
        activeAisCount={isHistoricalMode ? combinedVessels.length : enrichedLiveVessels.length}
        liveAisCount={enrichedLiveVessels.length}
        aisStatus={aisStatus}
        aisError={aisError}
        weather={effectiveWeather}
        nextSatellitePass={nextSatellitePass}
        feedDiagnostics={feedDiagnostics}
        hudMode={hudMode}
        hudMinimized={hudMinimized}
        alertsCount={activeAlertsCount}
        unreadAlertsCount={unreadAlertsCount}
        alertsOpen={alertsOpen}
        onSelectScenario={handleSelectScenario}
        onResyncFeeds={() => syncAllLiveFeeds(true)}
        onReconnectAisRelay={handleReconnectAisRelay}
        onToggleAlertsDrawer={() => setAlertsOpen((prev) => !prev)}
        onChangeMode={handleChangeMode}
        onToggleMinimize={() => setHudMinimized((prev) => !prev)}
      />

      {/* 2b. Automated Tactical Notification Feed (Toast + Alert Log Drawer) */}
      <TacticalNotificationFeed
        alerts={tacticalAlerts}
        drawerOpen={alertsOpen}
        latestToastAlert={latestToastAlert}
        onCloseDrawer={() => setAlertsOpen(false)}
        onOpenDrawer={() => {
          setAlertsOpen(true);
          setToastAlertId(null);
        }}
        onDismissToast={(id) => {
          if (toastAlertId === id) setToastAlertId(null);
        }}
        onAcknowledgeAlert={handleAcknowledgeAlert}
        onAcknowledgeAll={handleAcknowledgeAllAlerts}
        onClearResolved={handleClearResolvedAlerts}
        onLocateAlertVessel={handleLocateAlertVessel}
      />

      {/* 3. Left Panel — Live AIS / Historical Maritime Targets & Threat Triage */}
      <div
        className={`transition-all duration-200 ease-out ${
          hudMinimized
            ? 'opacity-0 -translate-x-8 pointer-events-none'
            : 'opacity-100 translate-x-0'
        }`}
      >
        <IncidentTriagePanel
          hudMode={hudMode}
          incidents={filteredIncidents}
          liveVessels={isHistoricalMode ? combinedVessels : enrichedLiveVessels}
          darkEnvelopes={isHistoricalMode ? [] : darkEnvelopes}
          cableThreatAlerts={isHistoricalMode ? [] : cableThreatAlerts}
          nextSatellitePass={nextSatellitePass}
          aisStatus={isHistoricalMode ? 'connected' : aisStatus}
          aisError={aisError}
          activeFilter={incidentFilter}
          selectedIncidentId={selectedIncident.id}
          selectedVesselId={selectedVessel?.id ?? null}
          onChangeFilter={setIncidentFilter}
          onLocateIncident={handleLocateIncident}
          onInspectIncident={handleInspectIncident}
          onSelectLiveVessel={handleSelectLiveVesselFromList}
          onReconnectAis={handleReconnectAisRelay}
        />
      </div>

      {/* 4. Right Panel — Target Physics, Attribution & Cost Inspector */}
      <div
        className={`transition-all duration-200 ease-out ${
          hudMinimized
            ? 'opacity-0 translate-x-8 pointer-events-none'
            : 'opacity-100 translate-x-0'
        }`}
      >
        <TargetInspectorPanel
          hudMode={hudMode}
          incident={selectedIncident}
          vessel={selectedVessel}
          weather={effectiveWeather}
          asfScenes={effectiveAsfScenes}
          selectedAsfSceneId={resolvedAsfSceneId}
          inspectTargetMode={inspectTargetMode}
          liveSnapshot={liveForensicSnapshot}
          queuedSarTasks={queuedSarTasks}
          activeTab={inspectorTab}
          onChangeTab={setInspectorTab}
          onSelectAsfScene={(sceneId) => handleSelectAsfScene(sceneId, true)}
          onSimulateBlackout={handleSimulateBlackout}
          onAdvanceBlackout={handleAdvanceBlackout}
          onClearBlackout={handleClearBlackout}
          onQueueSarTask={handleQueueSarTask}
          onTriggerLiveOilSpill={handleTriggerLiveOilSpill}
          onClearLiveOilSpill={handleClearLiveOilSpill}
          onOpenDossier={() => setDossierOpen(true)}
        />
      </div>

      {/* 5. Bottom Control Deck — Time-Machine / 24h Historical Scrubber & Layer Matrix */}
      <BottomControlDeck
        baseMap={baseMap}
        layers={layers}
        timeOffsetHours={timeOffsetHours}
        isPlaying={isHistoricalMode ? historicalPlaying : isPlaying}
        hudMinimized={hudMinimized}
        isHistoricalMode={isHistoricalMode}
        historicalDateStr={historicalPayload?.dateStr}
        historicalMinute={historicalMinute}
        historicalDarkMinute={historicalPayload?.darkDropoutMinute}
        historicalPassMinute={historicalPayload?.primaryPassMinute}
        historicalPhase={historicalReplay?.phase}
        onChangeBaseMap={setBaseMap}
        onToggleLayer={handleToggleLayer}
        onChangeTimeOffset={(h) => {
          setIsPlaying(false);
          setTimeOffsetHours(h);
        }}
        onChangeHistoricalMinute={(m) => {
          setHistoricalPlaying(false);
          setHistoricalMinute(Math.max(0, Math.min(1439, m)));
        }}
        onTogglePlay={() => {
          if (isHistoricalMode) {
            if (!historicalPlaying && historicalMinute >= 1439) {
              setHistoricalMinute(0);
            }
            setHistoricalPlaying((p) => !p);
          } else {
            setIsPlaying((p) => !p);
          }
        }}
        onResetTime={handleResetTime}
      />

      {/* 6. Printable Forensic Violation Dossier Modal */}
      {dossierOpen && (
        <ViolationDossierModal
          hudMode={hudMode}
          incident={selectedIncident}
          vessel={selectedVessel}
          weather={effectiveWeather}
          liveSnapshot={liveForensicSnapshot}
          queuedSarTasks={queuedSarTasks}
          onClose={() => setDossierOpen(false)}
        />
      )}

      {/* 7. Initial Entry Mission Briefing Modal */}
      {briefingOpen && (
        <MissionBriefingModal onEnter={() => setBriefingOpen(false)} />
      )}
    </div>
  );
}
